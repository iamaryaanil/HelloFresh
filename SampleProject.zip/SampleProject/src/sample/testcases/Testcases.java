package sample.testcases;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import sample.pages.SignIn;
import sample.pages.CheckOut;
import sample.pages.Login;
import sample.utilities.Report;

public class Testcases {

	ExtentReports extent;
	ExtentTest exTest;
	String filepath = "C:\\HelloFresh\\Reports\\HTMLReport.html";
	Report test = new Report();
	WebDriver driver;
	SignIn sign = new SignIn(driver);
	Login login = new Login(driver);
	CheckOut check = new CheckOut(driver);

	@BeforeTest
	public void beforeTest() throws IOException, ParserConfigurationException, SAXException {
		// Initializing the reporting used -Extent Reports
		test.ExtentReports(filepath, true);
	}

	/// <summary>
	/// Test case 1 : Sign in functionality
	/// </summary>
	@Test
	public void SignInTestCase() throws IOException, InterruptedException {
		sign.launchBrowser("Chrome");
		test.WriteLog("pass", "Browser launched");
		sign.click();
		test.WriteLog("pass", "Sign in clicked");
		sign.enterEmail();
		test.WriteLog("pass", "Email entered");
		sign.clickCreateAccount();
		test.WriteLog("pass", "Create Account clicked");
		sign.selectTitle();
		test.WriteLog("pass", "Title selected successfully");
		sign.enterFirstName("First");
		test.WriteLog("pass", "First name entered successfully");
		sign.enterLastName("Last");
		test.WriteLog("pass", "Last name entered successfully");
		sign.enterPassword("Qwerty");
		test.WriteLog("pass", "Password entered successfully");
		sign.enterDob("1", "1", "2000");
		test.WriteLog("pass", "DOB entered successfully");
		sign.enterCompany("Company");
		test.WriteLog("pass", "Sucessfully entered Company name");
		sign.enterAddress1("add1");
		test.WriteLog("pass", "Sucessfully entered Address1");
		sign.enterAddress2("add2");
		test.WriteLog("pass", "Sucessfully entered Address2");
		sign.enterCity("city");
		test.WriteLog("pass", "Sucessfully entered City");
		sign.selectState("Colorado");
		test.WriteLog("pass", "Successfully entered State");
		sign.enterPostal("12345");
		test.WriteLog("pass", "Successfully entered Post Code");
		sign.enterOther("other");
		test.WriteLog("pass", "Successfully entered Other");
		sign.enterPhone("9563320533");
		test.WriteLog("pass", "Successfully entered Phone");
		sign.enterMobile("4543364453");
		test.WriteLog("pass", "Successfully entered Mobile");
		sign.enterAlias("alias");
		test.WriteLog("pass", "Successfully entered Alias");
		sign.clickRegister();
		test.WriteLog("pass", "Account created successfully");
		sign.verifyAccountCreated("First", "Last");
		test.WriteLog("pass", "Account verified successfully");
		sign.clickLogout();
	}

	/// <summary>
	/// Test case 1 : Login functionality
	/// </summary>
	@Test
	public void Login() throws InterruptedException, IOException, Exception, Throwable {
		String fname = "Joe";
		String lname = "Black";

		sign.launchBrowser("Chrome");
		test.WriteLog("pass", "Browser launched");
		sign.click();
		test.WriteLog("pass", "Login clicked");
		Thread.sleep(2000);
		login.enterEmail();
		test.WriteLog("pass", "Email entered successfully");
		login.enterPassword("Qwerty");
		test.WriteLog("pass", "Password entered successfully");
		login.clickSumbit();
		test.WriteLog("pass", "Login successful");
		login.verifyAccountLoggedIn(fname, lname);
		test.WriteLog("pass", "Account verified");
	}

	/// <summary>
	/// Test case 3 : Checkout dress. The size, color and quantity of the dress are
	/// read from excel sheet
	/// </summary>
	@Test
	public void Checkout() throws InterruptedException, IOException, Exception, Throwable {
		sign.launchBrowser("Chrome");
		test.WriteLog("pass", "Browser launched");
		sign.click();
		test.WriteLog("pass", "Login clicked");
		login.enterEmail();
		test.WriteLog("pass", "Email entered successfully");
		login.enterPassword("Qwerty");
		test.WriteLog("pass", "Password entered successfully");
		login.clickSumbit();
		test.WriteLog("pass", "Login successful");
		check.clickWomen();
		test.WriteLog("pass", "Women option selected");
		check.clickTshirt();
		test.WriteLog("pass", "Faded tshirt selected");
		check.clickTshirt();
		check.enterQuantity();
		test.WriteLog("pass", "Quantity entered");
		check.selectSize();
		test.WriteLog("pass", "Size selected");
		check.selectColor();
		test.WriteLog("pass", "Color selected");
		check.clickAddToCart();
		test.WriteLog("pass", "Tshirt added to cart");
		check.clickProceedToCheckOut();
		test.WriteLog("pass", "Clicked Proceed To Checkout");
		check.clickProceedToCheckOutCart();
		test.WriteLog("pass", "Clicked Proceed To Checkout");
		check.clickProcessAddress();
		test.WriteLog("pass", "Clicked Proceed To Checkout");
		check.clickIAgree();
		test.WriteLog("pass", "Clicked I agree to terms of service");
		check.clickProcessCarrier();
		test.WriteLog("pass", "Clicked Proceed To Checkout");
		check.clickPayByBankWire();
		test.WriteLog("pass", "Clicked Pay By Bank Wire");
		check.clickConfirmOrder();
		test.WriteLog("pass", "Clicked I confirm my order");
		check.verifyOrderPlaced();
		test.WriteLog("pass", "Order placed successfully");
	}

	@AfterTest
	public void afterTest() {
		test.stop();
	}
}

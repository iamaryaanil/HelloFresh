package sample.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import sample.utilities.Utilities;


public class SignIn extends Utilities {
	
By login= By.className("login");
By Email=By.id("email_create");
By CreateAccount=By.id("SubmitCreate");
By Title=By.id("id_gender2");
By Firstname=By.id("customer_firstname");
By Lastname=By.id("customer_lastname");
By Password=By.id("passwd");
By Day=By.id("days");
By Month=By.id("months");
By  Year=By.id("years");
By Company=By.id("company");
 By Address1=By.id("address1");
By Address2=By.id("address2");
By City=By.id("city");
 By State=By.id("id_state");
By PostCode=By.id("postcode");
By Other=By.id("other");
By Phone=By.id("phone");
By Mobile=By.id("phone_mobile");
By Alias=By.id("alias");
By Submit=By.id("submitAccount");
By Heading=By.cssSelector("h1");
By Account=By.className("account");
By TitleText=By.className("info-account");
By Logout=By.className("logout");

	public SignIn(WebDriver driver) {
		super(driver);
		
	}
		public void launchBrowser(String browser) throws IOException, InterruptedException {
			String email=readDetails(1,3);
		System.out.println(email);
			launchBrowser(browser,"http://automationpractice.com/index.php");
		}
		
		public void click() throws IOException, InterruptedException {
			clickElement(login);
		}
		
		public void enterEmail() throws IOException {
			String emailId = GenerateRandomString(7) + "@gmail.com";
			typeText(Email, emailId);
		}
		
		public void clickCreateAccount() throws IOException {
			clickElement(CreateAccount);
		}
	
		public void selectTitle() throws InterruptedException, IOException {
			Thread.sleep(4000);
			clickElement(Title);
		}

		public void enterFirstName(String fname) throws IOException {
			typeText(Firstname, fname);
		}

		public void enterLastName(String lname) throws IOException {
			typeText(Lastname, lname);
		}

		public void enterPassword(String password) throws IOException {
			typeText(Password, password);
		}

		public void enterDob(String day, String month, String year) throws IOException {
			selectElementByValue(Day, day);
			selectElementByValue(Month, month);
			selectElementByValue(Year, year);
		}

		public void enterCompany(String company) throws IOException {
			typeText(Company, company);
		}

		public void enterAddress1(String add1) throws IOException {
			typeText(Address1, add1);
		}

		public void enterAddress2(String add2) throws IOException {
			typeText(Address2, add2);
		}

		public void enterCity(String city) throws IOException {
			typeText(City, city);
		}

		public void selectState(String state) throws IOException {
			selectElementByText(State, state);
		}

		public void enterPostal(String post) throws IOException {
			typeText(PostCode, post);
		}

		public void enterOther(String other) throws IOException {
			typeText(Other, other);
		}

		public void enterPhone(String phone) throws IOException {
			typeText(Phone, phone);
		}

		public void enterMobile(String mobile) throws IOException {
			typeText(Mobile, mobile);
		}

		public void enterAlias(String alias) throws IOException {
			typeText(Alias, alias);
		}

		public void clickRegister() throws IOException {
			clickElement(Submit);
		}
		
		public void verifyAccountCreated(String fname, String lname) throws IOException, InterruptedException {
			Thread.sleep(5000);
			verifyAssertEquals(Heading,"MY ACCOUNT", "Heading verified");
			verifyAssertEquals(Account,fname+" "+lname,"Account verified");
			//verifyAssertTrue(TitleText,"Welcome to your account. Here you can manage all of your personal information and orders.", "Title verified");
			verifyElementDisplayed(Logout,"Logout is displayed");
			verifyURL("controller=my-account");
		}

		public void clickLogout() throws IOException {
			clickElement(Logout);
			closeBrowser();
		}
	 	

}

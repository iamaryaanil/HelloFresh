package sample.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import sample.utilities.Utilities;

public class Login extends Utilities{

	By Email= By.id("email");
	By Password= By.id("passwd");
	By Submit= By.id("SubmitLogin");
	By Heading= By.cssSelector("h1");
	By Account= By.className("account");
	By TitleText= By.className("info-account");
	By Logout= By.className("logout");
	
	public Login(WebDriver driver) {
		super(driver);
	}
	
	public void enterEmail() throws IOException {
		String emailId = "testemail@gmail.com";
		typeText(Email, emailId);
	}

	public void enterPassword(String password) throws IOException {
		typeText(Password, password);
	}

	public void clickSumbit() throws IOException {
		clickElement(Submit);
	}

	public void verifyAccountLoggedIn(String fname, String lname) throws IOException, InterruptedException {
		
		Thread.sleep(5000);
		verifyAssertEquals(Heading,"MY ACCOUNT", "Heading verified");
		verifyAssertEquals(Account,fname+" "+lname,"Account verified");
		verifyElementDisplayed(Logout,"Logout is displayed");
		verifyURL("controller=my-account");
	}
}

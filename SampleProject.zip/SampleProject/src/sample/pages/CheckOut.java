package sample.pages;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import sample.utilities.Utilities;

public class CheckOut extends Utilities{

	By Women= By.linkText("Women");
	By Tshirt= By.xpath("//a[@title='Faded Short Sleeve T-shirts']/ancestor::li");
	By Quantity= By.id("quantity_wanted");
	By Size= By.id("group_1");
	By ColorOrange= By.xpath("//a[@title='Orange']");
	By ColorBlue= By.xpath("//a[@title='Blue']");
	By Submit= By.name("Submit");
	By ProceedToCheckOut= By.xpath("//*[@id='layer_cart']//a[@class and @title='Proceed to checkout']");
	By ProceedToCheckOutCart =By.xpath("//*[contains(@class,'cart_navigation')]/a[@title='Proceed to checkout']");
	By ProcessAddress= By.name("processAddress");
	By Iagree= By.id("uniform-cgv");
	By ProcessCarrier= By.name("processCarrier");
	By PayByBankWire= By.className("bankwire");
	By ConfirmOrder= By.xpath("//*[@id='cart_navigation']/button");
	By Heading= By.cssSelector("h1");
	By Text1= By.xpath("//li[@class='step_done step_done_last four']");
	By Text2= By.xpath("//li[@id='step_end' and @class='step_current last']");
	By Text3= By.xpath("//*[@class='cheque-indent']/strong");
	
	public CheckOut(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void clickWomen() throws IOException {
		clickElement(Women);
	}

	public void clickTshirt() throws IOException {
		clickElement(Tshirt);
	}

	public void enterQuantity() throws IOException {
		int quantity = readQuantity(1, 0);
		String val = Integer.toString(quantity);
		typeText(Quantity, val);
	}

	public void selectSize() throws IOException {
		String size = readDetails(1, 1);
		selectElementByText(Size, size);
	}

	public void selectColor() throws IOException {
		String color = readDetails(1, 2);
		System.out.println(color);
		if (color.equals("Orange")) {
			clickElement(ColorOrange);
		} else if (color.equals("Blue")) {
			clickElement(ColorBlue);
		}
	}

	public void clickAddToCart() throws IOException {
		clickElement(Submit);
	}

	public void clickProceedToCheckOut() throws IOException, InterruptedException {
		Thread.sleep(1000);
		clickElement(ProceedToCheckOut);
	}

	public void clickProceedToCheckOutCart() throws IOException {
		clickElement(ProceedToCheckOutCart);
	}

	public void clickProcessAddress() throws IOException {
		clickElement(ProcessAddress);
	}

	public void clickIAgree() throws IOException {
		clickElement(Iagree);
	}

	public void clickProcessCarrier() throws IOException {
		clickElement(ProcessCarrier);
	}

	public void clickPayByBankWire() throws IOException {
		clickElement(PayByBankWire);
	}

	public void clickConfirmOrder() throws IOException {
		clickElement(ConfirmOrder);
	}

	public void verifyOrderPlaced() throws IOException, InterruptedException {
		Thread.sleep(3000);
		verifyAssertEquals(Heading,"ORDER CONFIRMATION", "Heading verified");
		verifyElementDisplayed(Text1,"Text displayed");
		verifyElementDisplayed(Text2,"Text displayed");
		verifyAssertTrue(Text3,"Your order on My Store is complete.","Message verified");
		verifyURL("controller=order-confirmation");
	}
}

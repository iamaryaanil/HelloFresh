package sample.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.client.ClientProtocolException;

/// <summary>
/// Program to get all countries in the given web service and also to check the existence of the countries US,DE and GB
/// </summary>
public class Function1 {

	public static void main(String[] args) {
		try {
			URL url = new URL("http://services.groupkt.com/country/get/all");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP Error code : " + conn.getResponseCode());
			}
			InputStreamReader in = new InputStreamReader(conn.getInputStream());
			BufferedReader br = new BufferedReader(in);
			String output = null;
			StringBuffer response = new StringBuffer();
			while ((output = br.readLine()) != null) {
				response.append(output);
			}
			conn.disconnect();
			String myResponseString = response.toString();
			System.out.println(myResponseString);
			if (myResponseString.contains("US")) {
				System.out.println("Response contains the code : US");
			}
			if (myResponseString.contains("GE")) {
				System.out.println("Response contains the code : GE");
			}
			if (myResponseString.contains("GB")) {
				System.out.println("Response contains the code : GB");
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}
}

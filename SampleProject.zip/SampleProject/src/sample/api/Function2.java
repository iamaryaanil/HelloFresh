	package sample.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/// <summary>
/// Program to get each country and validate the response for the code. The countries provided are US,DE,GB.Also to check the response code for a non existing country
/// </summary>
public class Function2 {

	public static void main(String[] args) throws IOException {

		// Validating response code for US, DE, GB
		getResponse("http://services.groupkt.com/country/get/iso2code/us", "US");
		getResponse("http://services.groupkt.com/country/get/iso2code/de", "DE");
		getResponse("http://services.groupkt.com/country/get/iso2code/gb", "GB");

		// Validating response code for a country that is not existing */
		getResponse("http://services.groupkt.com/country/get/iso2code/tc", "TC");
	}

	/// <summary>
	/// Function to validate the response code for the URL provided
	/// </summary>
	public static void getResponse(String value, String code) throws IOException {
		try {
			URL url = new URL(value);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP Error code : " + conn.getResponseCode());
			}
			InputStreamReader in = new InputStreamReader(conn.getInputStream());
			BufferedReader br = new BufferedReader(in);
			String output = null;
			StringBuffer response = new StringBuffer();
			while ((output = br.readLine()) != null) {
				response.append(output);
			}
			conn.disconnect();
			String myResponseString = response.toString();
			int responseCode = conn.getResponseCode();
			System.out.println("Response string for " + code + ":" + myResponseString);
			System.out.println("Response code:" + responseCode);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}
}

package sample.api;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

/// <summary>
/// Program to POST a json to add a new country
/// </summary>
public class Function3 {
	public static void main(String[] args) throws ClientProtocolException, IOException {

		// Json body is defined
		String responseBody = "\"RestResponse\" : {" + "\"result\" : [ {" + "\"name\" : " + "\"Test Country\" ,"
				+ "\"alpha2_code\" : " + "\"TC\" ," + "\"alpha3_code\" : " + "\"TCY\" ," + "}";

		StringEntity entity = new StringEntity(responseBody, "application/json");
		HttpClient client = HttpClientBuilder.create().build();
		HttpPost request = new HttpPost("");
		request.setEntity(entity);
		HttpResponse response = client.execute(request);
		System.out.println(response.getStatusLine().getStatusCode());
	}
}

package sample.utilities;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Random;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utilities {
	public WebDriver driver;
	
	public WebDriverWait wait;
	
	 public Utilities (WebDriver driver) {
		 this.driver= driver;
		 
	 }
	
	/// <summary>
	/// Function to launch the browser
	/// </summary>
	public void launchBrowser(String browser,String url) {
		if (browser == "Chrome") {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Workspace\\SampleProject\\src\\sample\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser == "IE") {
			System.setProperty("webdriver.ie.driver",
					"C:\\Workspace\\SampleProject\\src\\sample\\drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else if (browser == "Firefox") {
			System.setProperty("webdriver.gecko.driver",
					"C:\\Workspace\\SampleProject\\src\\sample\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.get(url);
		driver.manage().window().maximize();
	}	
	
    

	/// <summary>
	/// Function to enter values in text box
	/// </summary>
	public void typeText(By element, String value) {
		driver.findElement(element).sendKeys(Keys.ENTER);
		driver.findElement(element).sendKeys(value);
	}

	/// <summary>
	/// Function to click an element
	/// </summary>
	public void clickElement(By element) throws IOException {
		driver.findElement(element).click();
	}

	/// <summary>
	/// Function to select from drop down using value
	/// </summary>
	public void selectElementByValue(By element, String value) {
		Select select = new Select(driver.findElement(element));
		select.selectByValue(value);
	}

	/// <summary>
	/// Function to select from drop down using text
	/// </summary>
	public void selectElementByText(By element, String text) {
		Select select = new Select(driver.findElement(element));
		select.selectByVisibleText(text);
	}

	/// <summary>
	/// Function to generate random string of given length
	/// </summary>
	public String GenerateRandomString(int length) {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();
		return generatedString;

	}

	/// <summary>
	/// Function to read numeric value from excel
	/// </summary>
	public int readQuantity(int row, int col) throws IOException {
		int value;
		// Path where excel is located
		File excelFile = new File("C:\\Workspace\\SampleProject\\src\\sample\\testdata\\TestData.xlsx");
		FileInputStream fis = new FileInputStream(excelFile);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);
		value = (int) sheet.getRow(row).getCell(col).getNumericCellValue();
		return value;
	}

	/// <summary>
	/// Function to read string from excel
	/// </summary>
	public String readDetails(int row, int col) throws IOException {
		String value;
		File excelFile = new File("C:\\Workspace\\SampleProject\\src\\sample\\testdata\\TestData.xlsx");
		FileInputStream fis = new FileInputStream(excelFile);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);
		value = sheet.getRow(row).getCell(col).getStringCellValue();
		return value;
	}
	
	/// <summary>
	/// Function to verify the text
	/// </summary>
	public void verifyAssertEquals(By element, String expected, String message) {
		assertEquals(driver.findElement(element).getText(), expected, message);
	}
	
	/// <summary>
	/// Function to verify the text
	/// </summary>
	public void verifyAssertTrue(By element, String expected,String message) {
		System.out.println(driver.findElement(element).getText());
		assertEquals(driver.findElement(element).getText().contains(expected), message);
	}
	
	/// <summary>
	/// Function to find a element is displayed
	/// </summary>
	public void verifyElementDisplayed(By element,String message) {
		assertTrue(driver.findElement(element).isDisplayed(),message);
	}
	
	/// <summary>
	/// Function to verify url
	/// </summary>
	public void verifyURL(String value) {
		String url =driver.getCurrentUrl();
		if(url.contains(value)) {
			System.out.println("Url verified");
		}
	}
	
	/// <summary>
	/// Function to close browser
	/// </summary>
	public void closeBrowser() {
		driver.quit();
	}
}

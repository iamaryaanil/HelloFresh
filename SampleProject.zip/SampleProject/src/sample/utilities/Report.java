package sample.utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Report {
	ExtentReports extent;
	ExtentTest exTest;
	Utilities util;
	public static String dir = "C:\\HelloFresh\\Reports";
    
	/// <summary>
	/// Function to start the report log
	/// </summary>
	public void ExtentReports(String string2, boolean b)
	{
		 File files = new File(dir);
		    if (!files.exists()) 
		    {
		        if (files.mkdirs()) 
		        {
		            System.out.println("Sub directory is created!");
		        } else {
		            System.out.println("Failed to create Sub directory");
		        }
		    }
		    extent= new ExtentReports(string2, false);
			exTest=  extent.startTest("Test Case Execution");
	 }
	
	/// <summary>
	/// Function to write reports
	/// </summary>
	public void WriteLog(String status, String msg) throws IOException{
		status = status.toLowerCase();
	    if (status.equals("info"))
	    {
	        exTest.log(LogStatus.INFO, msg);
	    }
	    else if (status.equals("pass"))
	    {
	        exTest.log(LogStatus.PASS, msg);
	    }
	    else if (status.equals("fail"))
	    {
	    	String filename = exTest.getTest().getName() +".jpeg";
	        TakeScreenshot(util.driver, filename,dir);
	        exTest.log(LogStatus.FAIL, "Image", msg + exTest.addScreenCapture("./" + filename));
	        exTest.log(LogStatus.FAIL, msg);
	    }
	    else if (status.equals("fatal"))
	    {
	        exTest.log(LogStatus.FATAL, msg);
	    }
	    else if (status.equals("error"))
	    {
	        String filename = exTest.getTest().getName() + ".jpeg";
	        TakeScreenshot(util.driver, filename, dir);
	        exTest.log(LogStatus.FAIL, "Image", msg + exTest.addScreenCapture("./" + filename));
	        exTest.log(LogStatus.ERROR, msg);
	    }
	    else if (status.equals("warning"))
	    {
	        String filename = exTest.getTest().getName()+ ".jpeg";
	        TakeScreenshot(util.driver, filename, dir);
	        exTest.log(LogStatus.FAIL, "Image", msg + exTest.addScreenCapture("./" + filename));
	        exTest.log(LogStatus.WARNING, msg);
	    }
	    else if (status.equals("skip"))
	    {
	        exTest.log(LogStatus.SKIP, msg);
	    }
	}
	
	/// <summary>
	/// Function to take screenshot
	/// </summary>
	public void TakeScreenshot(WebDriver driver, String fileName, String folder) throws IOException{
		
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("c:\\tmp\\screenshot.png"));
	}
	
	/// <summary>
	/// Function to end test case and flush the extent reports
	/// </summary>
	public void stop() {
		extent.endTest(exTest);
		extent.flush();	
	}
}
